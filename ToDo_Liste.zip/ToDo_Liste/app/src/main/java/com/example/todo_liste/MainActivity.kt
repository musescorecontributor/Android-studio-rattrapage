package com.example.todo_liste

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.SparseBooleanArray
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // initialise la liste d'objets ainsi que l'adapter
        var liste_tache = arrayListOf<String>() // affiche le contenu de ma liste
        var adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, liste_tache) // à chaque fois qu'on ajoute un élément dans le bouton ajouter on voit la liste

        val ajouter = findViewById(R.id.Ajouter) as Button //Cherche l'id Button
        val editText: EditText = findViewById(R.id.Mon_edit_text) as EditText // cherche l'id du editText
        val listView: ListView = findViewById(R.id.liste_de_vue) as ListView  // cherche l'id du listeview


        // l'événment onclick du bouton ajouter nous permet de pouvoir ajouter à la liste de nouvelles tâches dans un tableau
        ajouter.setOnClickListener {
            liste_tache.add(editText.text.toString())
            listView.adapter =  adapter
            adapter.notifyDataSetChanged()

            //à chaque fois qu'on ajoute une tache on va rafraichir la barre de saisie du texte
            editText.text.clear()
        }
        // on attache au bouton supprimer une vue de l'objet et qui va permettre d'appeller un listener sur le bouton
        val supprimer: Button = findViewById(R.id.supprimer) as Button

        //on selectionne et supprime les taches depuis la liste quand le bouton supprimer est appellé
        supprimer.setOnClickListener {
            val position: SparseBooleanArray = listView.checkedItemPositions
            val count = listView.count
            var item = count - 1
            while (item >= 0) {
                if (position.get(item))
                {
                    adapter.remove(liste_tache.get(item))
                }
                item--
            }
            position.clear()
            adapter.notifyDataSetChanged()
        }
        // rafraichit la liste de tache que le bouton rafraichir est cliqué
        val clear: Button = findViewById(R.id.effacer) as Button
        clear.setOnClickListener {

            liste_tache.clear()
            adapter.notifyDataSetChanged()

        }
        // ajouter un message box quand la liste de tache est appuyer
        listView.setOnItemClickListener { adapterView, view, i, l ->
            android.widget.Toast.makeText(this, "vous avez choisi la tache "+liste_tache.get(i), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

}